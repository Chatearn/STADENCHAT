import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 10000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "../..");

app.use(cors({ origin: process.env.CLIENT_URL || true }));
app.use(express.json());

const groups = [
  { id: "community", name: "Staden Community", description: "Meet people and join the conversation.", type: "public", members: 128, color: "violet" },
  { id: "business", name: "Business Connect", description: "Ideas, growth, and networking.", type: "public", members: 84, color: "blue" },
  { id: "vip-lounge", name: "VIP Lounge", description: "A private members-only community.", type: "private", feeKes: 200, members: 36, color: "amber" }
];

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "STADENCHAT" }));
app.get("/api/groups", (_req, res) => res.json({ groups }));

if (process.env.NODE_ENV === "production") {
  const distPath = path.join(projectRoot, "client", "dist");
  app.use(express.static(distPath));
  app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));
}

app.listen(PORT, () => console.log(`STADENCHAT server listening on ${PORT}`));
