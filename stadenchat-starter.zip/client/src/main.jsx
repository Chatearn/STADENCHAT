import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  MessageCircle, Search, Bell, Users, Compass, LockKeyhole, Hash,
  Plus, ArrowUpRight, Sparkles, Menu, X, CircleUserRound, Send, Crown
} from "lucide-react";
import "./styles.css";

const fallbackGroups = [
  { id: "community", name: "Staden Community", description: "Meet people and join the conversation.", type: "public", members: 128, color: "violet", icon: "✳" },
  { id: "business", name: "Business Connect", description: "Ideas, growth, and networking.", type: "public", members: 84, color: "blue", icon: "↗" },
  { id: "creators", name: "Creators Corner", description: "Share what you're making with the world.", type: "public", members: 62, color: "pink", icon: "✦" },
  { id: "vip-lounge", name: "VIP Lounge", description: "A private members-only community.", type: "private", feeKes: 200, members: 36, color: "amber", icon: "♛" }
];
const onlinePeople = [
  { name: "Amani W.", initials: "AW", color: "peach", status: "Talking about new ideas" },
  { name: "Brian K.", initials: "BK", color: "mint", status: "Exploring communities" },
  { name: "Nia M.", initials: "NM", color: "lilac", status: "Just joined" },
  { name: "Kevin O.", initials: "KO", color: "sky", status: "In Business Connect" }
];

function App() {
  const [groups, setGroups] = useState(fallbackGroups);
  const [activeTab, setActiveTab] = useState("Discover");
  const [search, setSearch] = useState("");
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    fetch("/api/groups").then(r => r.ok ? r.json() : null).then(data => {
      if (data?.groups) setGroups(data.groups.map(g => ({ ...g, icon: g.type === "private" ? "♛" : "✳" })));
    }).catch(() => {});
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);

  const filteredGroups = groups.filter(g =>
    `${g.name} ${g.description}`.toLowerCase().includes(search.toLowerCase()) &&
    (activeTab === "Discover" || activeTab === "Public groups" && g.type === "public" || activeTab === "Private groups" && g.type === "private")
  );
  const joinGroup = group => {
    if (group.type === "private") setNotice(`Private group: KSh ${group.feeKes || 200} joining payment will be enabled in a later build. No payment has been taken.`);
    else setNotice(`You've selected ${group.name}. Account creation and membership will be connected next.`);
    setSelectedGroup(group);
  };

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
      <div className="brand"><div className="brand-mark"><MessageCircle size={23} fill="currentColor" /></div><span>staden<span className="brand-light">chat</span><i>.</i></span><button className="mobile-close" onClick={() => setMobileMenu(false)}><X size={20}/></button></div>
      <div className="workspace-label">YOUR SPACE</div>
      <nav>
        {[["Discover", Compass], ["Public groups", Hash], ["Private groups", LockKeyhole]].map(([label, Icon]) =>
          <button key={label} className={`nav-link ${activeTab === label ? "active" : ""}`} onClick={() => {setActiveTab(label);setSelectedGroup(null);setMobileMenu(false);}}>
            <Icon size={19}/><span>{label}</span>{label === "Discover" && <span className="nav-new">NEW</span>}
          </button>
        )}
      </nav>
      <div className="sidebar-bottom">
        <div className="upgrade-card"><div className="upgrade-icon"><Crown size={18}/></div><strong>Find your circle.</strong><p>Good conversations start with the right people.</p><button onClick={() => {setActiveTab("Private groups");setMobileMenu(false)}}>Explore communities <ArrowUpRight size={15}/></button></div>
        <div className="profile-mini"><div className="avatar avatar-user">S</div><div className="profile-info"><strong>Guest visitor</strong><span>Preview mode</span></div><button className="more-button" aria-label="Profile options">···</button></div>
      </div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="mobile-menu-button" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={22}/></button>
        <div className="breadcrumb">Community <span>/</span> <b>{selectedGroup ? selectedGroup.name : activeTab}</b></div>
        <div className="top-actions"><button className="icon-button" aria-label="Notifications" onClick={() => setNotice("Notifications will be available when accounts are enabled.")}><Bell size={19}/></button><div className="top-avatar">S</div></div>
      </header>

      <div className="content">
        {selectedGroup ? <section className="detail-view">
          <button className="back-link" onClick={() => {setSelectedGroup(null);setNotice("");}}>← Back to communities</button>
          <div className={`group-hero-icon ${selectedGroup.color || "violet"}`}>{selectedGroup.type === "private" ? <LockKeyhole size={30}/> : <MessageCircle size={30}/>}</div>
          <div className="eyebrow">{selectedGroup.type === "private" ? "PRIVATE COMMUNITY" : "PUBLIC COMMUNITY"}</div>
          <h1>{selectedGroup.name}</h1><p className="detail-description">{selectedGroup.description}</p>
          <div className="detail-stats"><span><Users size={17}/> {selectedGroup.members} members</span>{selectedGroup.type === "private" && <span><LockKeyhole size={16}/> KSh {selectedGroup.feeKes || 200} joining fee (preview)</span>}</div>
          <button className="primary-button detail-join" onClick={() => joinGroup(selectedGroup)}>{selectedGroup.type === "private" ? "View membership options" : "Join community"} <ArrowUpRight size={17}/></button>
          <div className="preview-note"><Sparkles size={18}/><span>Community chat is coming next. This preview does not create a membership or process payments.</span></div>
        </section> : <>
          <section className="welcome-row"><div><div className="eyebrow"><span className="eyebrow-dot"></span> YOUR COMMUNITY, YOUR PEOPLE</div><h1>Find your <span className="gradient-text">people.</span></h1><p className="welcome-copy">Discover communities, share ideas, and be part of something.</p></div><div className="welcome-art"><div className="art-bubble bubble-one">✦</div><div className="art-bubble bubble-two"><MessageCircle size={24}/></div><div className="art-orbit orbit-one"></div><div className="art-orbit orbit-two"></div><div className="art-center"><Users size={34}/></div><div className="art-person person-one">A</div><div className="art-person person-two">N</div><div className="art-person person-three">B</div></div></section>
          <section className="stats-row"><div className="stat-card"><div className="stat-icon purple"><Users size={19}/></div><div><strong>Meet your people</strong><span>Communities built around you</span></div></div><div className="stat-card"><div className="stat-icon green"><MessageCircle size={19}/></div><div><strong>Real conversations</strong><span>Make every message count</span></div></div><div className="stat-card"><div className="stat-icon orange"><Sparkles size={19}/></div><div><strong>Your space to grow</strong><span>Discover new perspectives</span></div></div></section>

          <section className="community-section">
            <div className="section-heading"><div><div className="eyebrow">EXPLORE STADENCHAT</div><h2>{activeTab === "Discover" ? "Communities for you" : activeTab}</h2><p>There's a place for every conversation.</p></div><button className="outline-button" onClick={() => setNotice("Creating communities will be enabled with admin accounts in a later build.")}><Plus size={17}/> Create group</button></div>
            <div className="search-filter"><div className="search-box"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search communities..." aria-label="Search communities"/></div><div className="filter-pills">{["Discover","Public groups","Private groups"].map(t => <button key={t} className={activeTab === t ? "pill-active" : ""} onClick={() => setActiveTab(t)}>{t}</button>)}</div></div>
            <div className="group-grid">{filteredGroups.map((g, i) => <article className="group-card" key={g.id}><div className="card-top"><div className={`group-icon ${g.color || "violet"}`}>{g.type === "private" ? <Crown size={23}/> : g.icon || "✳"}</div><span className={`type-badge ${g.type}`}>{g.type === "private" ? <><LockKeyhole size={12}/> PRIVATE</> : <><Users size={12}/> PUBLIC</>}</span></div><h3>{g.name}</h3><p className="group-description">{g.description}</p><div className="group-meta"><div className="member-stack"><span>{["A","N","K"][i%3]}</span><span>{["M","J","S"][(i+1)%3]}</span><span>+</span></div><span>{g.members} members</span>{g.type === "private" && <strong className="fee">KSh {g.feeKes || 200}</strong>}</div><button className={`group-action ${g.type === "private" ? "private-action" : ""}`} onClick={() => joinGroup(g)}>{g.type === "private" ? "Explore membership" : "View community"} <ArrowUpRight size={16}/></button></article>)}</div>
            {filteredGroups.length === 0 && <div className="empty-state">No communities match that search. Try another name.</div>}
          </section>
        </>}
      </div>
      <footer className="footer"><span>© 2026 STADENCHAT</span><span>Made for meaningful connections <span className="footer-heart">♥</span></span></footer>
    </main>

    <aside className="right-panel"><div className="right-heading"><div><h3>People online</h3><p><span className="online-dot"></span> Live presence coming soon</p></div><button className="icon-button" onClick={() => setNotice("Live online status will be connected after account and real-time services are added.")} aria-label="Online status info"><ArrowUpRight size={17}/></button></div>
      <div className="online-count"><div className="online-count-avatars"><span>A</span><span>B</span><span>N</span><span>+</span></div><div><strong>Join the conversation</strong><p>Find new connections in groups.</p></div></div>
      <div className="people-list">{onlinePeople.map(p => <div className="person-row" key={p.name}><div className={`avatar ${p.color}`}>{p.initials}<span className="presence-dot"></span></div><div className="person-info"><strong>{p.name}</strong><span>{p.status}</span></div><button className="person-message" aria-label={`Message ${p.name}`} onClick={() => setNotice("Direct messages will be available in a later build.")}><MessageCircle size={16}/></button></div>)}</div>
      <div className="right-divider"></div><div className="tip-card"><div className="tip-icon"><Sparkles size={18}/></div><div><strong>A little reminder</strong><p>Great communities are built on kindness, curiosity, and respect.</p></div></div>
      <div className="right-bottom"><div className="right-bottom-mark"><MessageCircle size={17}/></div><div><strong>STADENCHAT</strong><span>Your people are here.</span></div></div>
    </aside>
    {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss"><X size={17}/></button></div>}
  </div>;
}

createRoot(document.getElementById("root")).render(<App />);
